package com.example.tictactoe

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.tictactoe.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Estado del tablero: "" vacío, "X" o "O"
    private val board = MutableList(9) { "" }
    private lateinit var cells: List<Button>

    private var currentPlayer = "X"
    private var gameActive = true

    private var scoreX = 0
    private var scoreO = 0
    private var scoreDraw = 0

    // Todas las combinaciones ganadoras posibles (índices del tablero)
    private val winningLines = listOf(
        intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8), // filas
        intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8), // columnas
        intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)                      // diagonales
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cells = listOf(
            binding.cell0, binding.cell1, binding.cell2,
            binding.cell3, binding.cell4, binding.cell5,
            binding.cell6, binding.cell7, binding.cell8
        )

        cells.forEachIndexed { index, button ->
            button.setOnClickListener { onCellClicked(index) }
        }

        binding.resetButton.setOnClickListener { resetBoard() }

        updateStatusText()
    }

    private fun onCellClicked(index: Int) {
        if (!gameActive || board[index].isNotEmpty()) return

        board[index] = currentPlayer
        val cell = cells[index]
        cell.text = currentPlayer
        cell.setTextColor(
            if (currentPlayer == "X") getColor(R.color.player_x)
            else getColor(R.color.player_o)
        )

        val winningLine = findWinningLine()
        when {
            winningLine != null -> {
                highlightWinningLine(winningLine)
                gameActive = false
                if (currentPlayer == "X") scoreX++ else scoreO++
                updateScoreText()
                binding.statusText.text = "¡Gana $currentPlayer!"
            }
            board.none { it.isEmpty() } -> {
                gameActive = false
                scoreDraw++
                updateScoreText()
                binding.statusText.text = "Empate"
            }
            else -> {
                currentPlayer = if (currentPlayer == "X") "O" else "X"
                updateStatusText()
            }
        }
    }

    private fun findWinningLine(): IntArray? {
        for (line in winningLines) {
            val (a, b, c) = line
            if (board[a].isNotEmpty() && board[a] == board[b] && board[b] == board[c]) {
                return line
            }
        }
        return null
    }

    private fun highlightWinningLine(line: IntArray) {
        for (index in line) {
            cells[index].setBackgroundResource(R.drawable.cell_background)
            cells[index].background.setTint(Color.parseColor("#414868"))
        }
    }

    private fun resetBoard() {
        for (i in board.indices) {
            board[i] = ""
            cells[i].text = ""
            cells[i].setBackgroundResource(R.drawable.cell_background)
        }
        currentPlayer = "X"
        gameActive = true
        updateStatusText()
    }

    private fun updateStatusText() {
        binding.statusText.text = "Turno de $currentPlayer"
    }

    private fun updateScoreText() {
        binding.scoreX.text = "X: $scoreX"
        binding.scoreO.text = "O: $scoreO"
        binding.scoreDraw.text = "Empates: $scoreDraw"
    }
}
